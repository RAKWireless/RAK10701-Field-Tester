//Your WiFi credentials
const char* ssid = "TRex";
const char* password =  "hasBigTeeth";

//Your RTK2GO mount point credentials
const char* mntpnt_pw = "WR5wRo4H";
const char* mntpnt = "bldr_dwntwn2";
